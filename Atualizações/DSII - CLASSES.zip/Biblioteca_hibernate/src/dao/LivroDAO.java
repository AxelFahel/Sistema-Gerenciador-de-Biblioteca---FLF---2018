package dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import model.Livro;


public class LivroDAO {
		
		
	public LivroDAO() {  }

	EntityManagerFactory factory = Persistence.createEntityManagerFactory("Biblioteca");
	
	/**
	 * Localiza um Livro pelo ISBN
	 * @param isbn ISBN do Livro
	 * @return Objeto da classe Livro
	 */
		public Livro localizar(int isbn) {

			EntityManager em = factory.createEntityManager();
			EntityTransaction t = em.getTransaction();
			Livro livro = null;
			
			try {

				t.begin();
				Query q = em.createQuery("from Livro where ISBN = :isbn");
				q.setParameter("isbn", isbn);
				livro = (Livro) q.getSingleResult();
				t.commit();

			} catch (Exception e) {

				e.printStackTrace();
				if (t.isActive()) t.rollback();

			} finally {

				em.close();
			}
			
			return livro;
		}

		/**
		 * Adiciona (Insere) um Livro
		 * @param livro Livro a ser persistido
		 * @param editora Editora do Livro
		 * @return True se bem sucedido, false se houve erro.
		 */
		public boolean inserir(Livro livro) {

			EntityManager em = factory.createEntityManager();
			EntityTransaction t = em.getTransaction();
			boolean result = false;
			
			try {

				t.begin();
				
				em.merge(livro);
				
				t.commit();
				result = true;

			} catch (Exception e) {
				
				e.printStackTrace();
				if (t.isActive()) t.rollback();

			} finally {

				em.close();

			}
			
			return result;
		}

		/**
		 * Exclui um Livro persisitido, pelo ISBN
		 * @param isbn ISBN do Livro
		 * @return True se bem sucedido, false se houve erro.
		 */
		public boolean excluir(int isbn) {

			EntityManager em = factory.createEntityManager();
			EntityTransaction t = em.getTransaction();
			Livro livro = null;
			boolean result = false;

			try {

				t.begin();
				Query q = em.createQuery("from Livro where isbn = :isbn");
				q.setParameter("isbn", isbn);
				
				livro = (Livro) q.getSingleResult();
				em.remove(livro);
				t.commit();
				result = true;

			} catch (Exception e) {

				e.printStackTrace();
				if (t.isActive()) t.rollback();

			} finally {

				em.close();
			}
			
			return result;
		}
		
}
