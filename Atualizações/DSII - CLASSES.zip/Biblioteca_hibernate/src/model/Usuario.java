package model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
	
@Entity
@Table(name="usuario")
public class Usuario {
		
		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		private int idUsuario;
	
		private String nome;
		private String sobreNome;
		
		@Temporal(value=TemporalType.DATE)
		private Date dtNascimento;
		
		private String RG;
		private String CPF;
		private String email;
		private String login;
		private String senha;
		
		@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY, mappedBy="emprestimoID.usuario")
		private List<Emprestimo> emprestimoItems = new ArrayList<Emprestimo>();

		
		public Usuario() { }
		
		public int getIdUsuario() {
			return idUsuario;
		}
		
		public void setIdUsuario(int idUsuario) {
			this.idUsuario = idUsuario;
		}
		
		public String getNome() {
			return nome;
		}
		
		public void setNome(String nome) {
			this.nome = nome;
		}

		public List<Emprestimo> getEmprestimoItems() {
			return emprestimoItems;
		}

		public void setEmprestimoItems(List<Emprestimo> emprestimoItems) {
			this.emprestimoItems = emprestimoItems;
		}

		public String getSobreNome() {
			return sobreNome;
		}

		public void setSobreNome(String sobreNome) {
			this.sobreNome = sobreNome;
		}

		public Date getDtNascimento() {
			return dtNascimento;
		}

		public void setDtNascimento(Date dtNascimento) {
			this.dtNascimento = dtNascimento;
		}

		public String getRG() {
			return RG;
		}

		public void setRG(String rG) {
			RG = rG;
		}

		public String getCPF() {
			return CPF;
		}

		public void setCPF(String cPF) {
			CPF = cPF;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getLogin() {
			return login;
		}

		public void setLogin(String login) {
			this.login = login;
		}

		public String getSenha() {
			return senha;
		}

		public void setSenha(String senha) {
			this.senha = senha;
		}
		
		
} 