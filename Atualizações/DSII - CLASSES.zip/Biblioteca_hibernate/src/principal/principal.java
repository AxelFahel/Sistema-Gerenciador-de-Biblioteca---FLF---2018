package principal;

import dao.EmprestimoDAO;
import dao.LivroDAO;
import model.Livro;
import java.util.Date;

import dao.UsuarioDAO;
import model.Usuario;

public class principal {

	public static void main(String[] args) {
		
		LivroDAO livroDAO =  new LivroDAO();
	    Livro livro = new Livro();
		Livro livro1 = new Livro();
		Livro livro2 = new Livro();
		
	    UsuarioDAO usuarioDAO = new UsuarioDAO();
	    Usuario u = new Usuario();
	    
	    EmprestimoDAO empr = new EmprestimoDAO();
	
		livro.setISBN(123456);
		livro.setTitulo("Franklin silva");
		livro.setAutores("Franklin Silva");
		livro.setPalavraChaves("Franklin");
		livro.setData(new Date());
		livro.setNumEdicao("1");
		livro.setEditora("TI");
		livro.setNumPaginas("250");
	
		livro1.setISBN(1234567);
		livro1.setTitulo("Franklin silva");
		livro1.setAutores("Franklin Silva");
		livro1.setPalavraChaves("Franklin");
		livro1.setData(new Date());
		livro1.setNumEdicao("1");
		livro1.setEditora("TI");
		livro1.setNumPaginas("250");
		
		livro2.setISBN(12345678);
		livro2.setTitulo("Franklin silva");
		livro2.setAutores("Franklin Silva");
		livro2.setPalavraChaves("Franklin");
		livro2.setData(new Date());
		livro2.setNumEdicao("1");
		livro2.setEditora("TI");
		livro2.setNumPaginas("250"); 
		
		//livroDAO.inserir(livro);
		//livroDAO.excluir(1);
		//livroDAO.excluir(3);
		
		
		//livroDAO.inserir(livro);
		//livroDAO.inserir(livro1);
		//livroDAO.inserir(livro2);
		
		//livroDAO.localizar(123456);
		//System.out.println(livro);
		
		//System.out.println(livroDAO.localizar(123456));
		
		
		
		u.setNome("Franklin");
		u.setSobreNome("Silva");
		u.setCPF("04591109348");
		u.setRG("205009007");
		//usuarioDAO.inserir(u);
		//System.out.println(usuarioDAO.localizar("Franklin"));
		
		empr.emprestar(livro, u);
		

	}

}
