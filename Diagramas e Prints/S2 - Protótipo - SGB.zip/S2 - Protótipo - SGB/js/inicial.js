function Nova()
{
location.href=" index.html"
}